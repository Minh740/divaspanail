﻿/* ============================== MAIN ============================== */
function ShowLoading() {
    $("#loading").fadeIn();
}


function HideLoading() {
    $("#loading").fadeOut();
}
